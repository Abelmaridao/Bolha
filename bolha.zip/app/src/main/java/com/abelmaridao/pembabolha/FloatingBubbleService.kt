package com.abelmaridao.pembabolha

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * Serviço que mantém a bolha flutuante visível por cima de outras apps.
 * Mostra: relógio (atualizado a cada segundo) e uma nota pessoal guardada no telemóvel.
 */
class FloatingBubbleService : Service() {

    companion object {
        private const val CHANNEL_ID = "bolha_channel"
        private const val NOTIF_ID = 1
        private const val PREFS = "bolha_prefs"
        private const val KEY_NOTE = "note"
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private lateinit var prefs: SharedPreferences

    private val clockHandler = Handler(Looper.getMainLooper())
    private var clockRunnable: Runnable? = null

    private var bubbleX = 0
    private var bubbleY = 200
    private lateinit var bubbleParams: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIF_ID, buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }
        showBubble()
    }

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: android.content.Intent?): IBinder? = null

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun buildNotification(): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID, "Bolha flutuante", NotificationManager.IMPORTANCE_MIN
            )
            mgr.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Bolha ativa")
            .setContentText("A bolha flutuante está a funcionar.")
            .setSmallIcon(android.R.drawable.presence_online)
            .setOngoing(true)
            .build()
    }

    // ---------- bolha fechada (ícone pequeno, arrastável) ----------
    private fun showBubble() {
        removePanel()
        if (bubbleView != null) return

        val view = LayoutInflater.from(this).inflate(R.layout.bubble_collapsed, null)
        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        bubbleParams.gravity = Gravity.TOP or Gravity.START
        bubbleParams.x = bubbleX
        bubbleParams.y = bubbleY

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = bubbleParams.x
                    startY = bubbleParams.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    bubbleParams.x = startX + dx
                    bubbleParams.y = startY + dy
                    windowManager.updateViewLayout(v, bubbleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    bubbleX = bubbleParams.x
                    bubbleY = bubbleParams.y
                    if (!moved) showPanel()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, bubbleParams)
        bubbleView = view
    }

    private fun removeBubble() {
        bubbleView?.let {
            windowManager.removeView(it)
            bubbleView = null
        }
    }

    // ---------- painel aberto (relógio + nota) ----------
    private fun showPanel() {
        removeBubble()
        if (panelView != null) return

        val view = LayoutInflater.from(this).inflate(R.layout.bubble_expanded, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bubbleX
        params.y = bubbleY

        val clock = view.findViewById<TextView>(R.id.panelClock)
        val note = view.findViewById<EditText>(R.id.panelNote)
        note.setText(prefs.getString(KEY_NOTE, ""))
        note.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString(KEY_NOTE, s?.toString() ?: "").apply()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })

        view.findViewById<View>(R.id.btnMin).setOnClickListener { showBubble() }
        view.findViewById<View>(R.id.btnClose).setOnClickListener { stopSelf() }

        windowManager.addView(view, params)
        panelView = view

        startClock(clock)
    }

    private fun removePanel() {
        panelView?.let {
            windowManager.removeView(it)
            panelView = null
        }
        stopClock()
    }

    private fun startClock(clock: TextView) {
        stopClock()
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val r = object : Runnable {
            override fun run() {
                clock.text = "H = ${fmt.format(Date())}"
                clockHandler.postDelayed(this, 1000)
            }
        }
        clockRunnable = r
        clockHandler.post(r)
    }

    private fun stopClock() {
        clockRunnable?.let { clockHandler.removeCallbacks(it) }
        clockRunnable = null
    }

    override fun onDestroy() {
        super.onDestroy()
        removeBubble()
        removePanel()
    }
}
